x = 42,
y = [for (x of 'abc') x],
[x, y]

